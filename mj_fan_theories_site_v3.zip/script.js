document.getElementById('explore-btn').addEventListener('click', function() {
    alert('Redirecting to Theories page...');
    window.location.href = 'theories.html';
});